﻿using ModelBindingAndDb.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ModelBindingAndDb.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult Index()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source =(localdb)\MsSqlLocalDb; Initial Catalog = jkDac20; Integrated Security = True; Pooling = False";

            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select *from employee2";
            SqlDataReader rd = cmd.ExecuteReader();
            List<Employee> lst = new List<Employee>();
           
            while (rd.Read())
            {
                // lst.AddRange(rd["EmpNo"]);
               // lst.Add(rd["Name"]);
              lst.Add(new Employee { EmpNo = Convert.ToInt32(rd["EmpNo"]), Name = (rd["Name"].ToString()), 
               Basic = Convert.ToDecimal(rd["Basic"]),DeptNo=Convert.ToInt32(rd["DeptNo"]) });
            
            }
            return View(lst);
            rd.Close();
            cn.Close();
        }

        // GET: Default/Details/5
        public ActionResult Details(int id=0)
        {
            // select record using empId
            /*Employee obj = new Employee();
            obj.EmpNo = 123;
            obj.Name = "Anjali";
            obj.Basic = 1234;
            obj.DeptNo = 10;*/
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source =(localdb)\MsSqlLocalDb; Initial Catalog = jkDac20; Integrated Security = True; Pooling = False";

            cn.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from employee2 where EmpNo=@EmpNo";
            cmd.Parameters.AddWithValue("@EmpNo", id);
            SqlDataReader rd = cmd.ExecuteReader();
            Employee empObj = new Employee();
            while(rd.Read())
            {
                empObj.EmpNo = Convert.ToInt32(rd["EmpNo"]);//set call
                empObj.Name = Convert.ToString(rd["Name"]);
                empObj.Basic = Convert.ToDecimal(rd["Basic"]);
                empObj.DeptNo = Convert.ToInt32(rd["DeptNo"]);
            }
              return View(empObj);
        }

        // GET: Default/Create
        public ActionResult Create()
        {
           return View();
        }

        // POST: Default/Create
        [HttpPost]
        public ActionResult Create(Employee empObj)
        {
            try
            {
                // TODO: Add insert logic here
                //string NAme=empObj.Name;
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @" Data Source= (localdb)\MsSqlLocalDb; Initial Catalog = jkDac20; Integrated Security = True; Pooling = False";

                cn.Open();

                SqlCommand cmdIns = new SqlCommand();
                cmdIns.Connection = cn;
                cmdIns.CommandType = CommandType.Text;
                cmdIns.CommandText = "insert into employee2 values(@EmpNo,@Name,@Basic,@DeptNo)";

                cmdIns.Parameters.AddWithValue("@EmpNo", empObj.EmpNo);
                cmdIns.Parameters.AddWithValue("@Name", empObj.Name);
                cmdIns.Parameters.AddWithValue("@Basic", empObj.Basic);
                cmdIns.Parameters.AddWithValue("@DeptNo", empObj.DeptNo);
                
                 cmdIns.ExecuteNonQuery();
                cn.Close();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }

            
        }

        // GET: Default/Edit/5
        public ActionResult Edit(int id=0)
        {
            /*Employee obj = new Employee();
            obj.EmpNo = 123;
            obj.Name = "Anjali";
            obj.Basic = 1234;
            obj.DeptNo = 10;*/
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source= (localdb)\MsSqlLocalDb; Initial Catalog = jkDac20; Integrated Security = True; Pooling = False";

            cn.Open();

            SqlCommand cmdUpd = new SqlCommand();
            cmdUpd.Connection = cn;
            cmdUpd.CommandType = CommandType.Text;
            cmdUpd.CommandText = "select * from employee2 where EmpNo=@EmpNo";
            cmdUpd.Parameters.AddWithValue("@EmpNo", id);

            SqlDataReader rd = cmdUpd.ExecuteReader();
            Employee empObj = new Employee();
            while (rd.Read())
            {
                empObj.EmpNo = Convert.ToInt32(rd["EmpNo"]);//set call
                empObj.Name = Convert.ToString(rd["Name"]);
                empObj.Basic = Convert.ToDecimal(rd["Basic"]);
                empObj.DeptNo = Convert.ToInt32(rd["DeptNo"]);
            }
            return View(empObj);

        }

        // POST: Default/Edit/5
        [HttpPost]
        public ActionResult Edit(int ? id, Employee empObj)
        {
            try
            {

                // TODO: Add update logic here
               /* int EmpNo = empObj.EmpNo;
                string Name = empObj.Name;
                decimal Basic = empObj.Basic;
                int DeptNo = empObj.DeptNo;*/

                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @" Data Source= (localdb)\MsSqlLocalDb; Initial Catalog = jkDac20; Integrated Security = True; Pooling = False";

                cn.Open();

                SqlCommand cmdUpd = new SqlCommand();
                cmdUpd.Connection = cn;
                cmdUpd.CommandType = CommandType.Text;
                cmdUpd.CommandText = "update employee2 set Name=@Name,Basic=@Basic,DeptNo=@DeptNo where EmpNo=@EmpNo";

                cmdUpd.Parameters.AddWithValue("@Name", empObj.Name);
                cmdUpd.Parameters.AddWithValue("@Basic", empObj.Basic);
                cmdUpd.Parameters.AddWithValue("@DeptNo", empObj.DeptNo);
                cmdUpd.Parameters.AddWithValue("@EmpNo", id);
                cmdUpd.ExecuteNonQuery();
                cn.Close();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Default/Delete/5
        public ActionResult Delete(int id=0)
        {

            /*objEmp.EmpNo = 123;
            objEmp.Name = "Vik";
            objEmp.Basic = 12345;
            objEmp.DeptNo = 10;*/
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @" Data Source= (localdb)\MsSqlLocalDb; Initial Catalog = jkDac20; Integrated Security = True; Pooling = False";

            cn.Open();

            SqlCommand cmdUpd = new SqlCommand();
            cmdUpd.Connection = cn;
            cmdUpd.CommandType = CommandType.Text;
            cmdUpd.CommandText = "select * from employee2 where EmpNo=@EmpNo";
            cmdUpd.Parameters.AddWithValue("@EmpNo", id);

            SqlDataReader rd = cmdUpd.ExecuteReader();
            Employee empObj = new Employee();
            while (rd.Read())
            {
                empObj.EmpNo = Convert.ToInt32(rd["EmpNo"]);//set call
                empObj.Name = Convert.ToString(rd["Name"]);
                empObj.Basic = Convert.ToDecimal(rd["Basic"]);
                empObj.DeptNo = Convert.ToInt32(rd["DeptNo"]);
            }
            return View(empObj);

        }

        // POST: Default/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Employee empObj)
        {
            try
            {
                // TODO: Add delete logic here
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = @" Data Source= (localdb)\MsSqlLocalDb; Initial Catalog = jkDac20; Integrated Security = True; Pooling = False";

                cn.Open();

                SqlCommand cmdDel = new SqlCommand();
                cmdDel.Connection = cn;
                cmdDel.CommandType = CommandType.Text;
                cmdDel.CommandText = "delete from employee2 where EmpNo=@EmpNo";
                cmdDel.Parameters.AddWithValue("@EmpNo", id);

                SqlDataReader rd = cmdDel.ExecuteReader();
                //Employee empObj = new Employee();
                while (rd.Read())
                {
                    empObj.EmpNo = Convert.ToInt32(rd["EmpNo"]);//set call
                    empObj.Name = Convert.ToString(rd["Name"]);
                    empObj.Basic = Convert.ToDecimal(rd["Basic"]);
                    empObj.DeptNo = Convert.ToInt32(rd["DeptNo"]);
                }
                return View(empObj);
                //return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
